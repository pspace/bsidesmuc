if (Java.available) {
    Java.perform(function() {
      const JavaStringClass = Java.use('java.lang.String');
      
    }
  )
}
