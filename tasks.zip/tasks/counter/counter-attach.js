'use strict;'

if (Java.available) {
    Java.perform(function() {

      Java.choose("space.polylog.owasp.needleremover.CounterActivity", {
        //onMatch will be called for every instance found by frida
        onMatch : function(instance){
          console.log("CounterActivity instance: "+ instance);
          instance.getCount.implementation = function(){
            return -1;
          };
        },
        onComplete:function(){}
    })
  }
)}
