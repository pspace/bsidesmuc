'use strict;'
if(Java.available){
  Java.perform(function() {
    const CounterActivity =
      Java.use("space.polylog.owasp.needleremover.CounterActivity");

    CounterActivity.getCount.implementation = function() {
      console.log("Asking for count");
      return 4630;
    }

    CounterActivity.incrementCount.implementation = function() {
      console.log("IncrementCount called.");
    }
  })
}
